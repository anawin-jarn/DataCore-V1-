class Relation: pass
