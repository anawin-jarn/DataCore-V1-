class Entity: pass
