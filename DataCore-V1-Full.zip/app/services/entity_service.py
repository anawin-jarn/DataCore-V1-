class EntityService: pass
